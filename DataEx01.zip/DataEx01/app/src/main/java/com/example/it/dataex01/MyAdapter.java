package com.example.it.dataex01;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.xml.sax.helpers.LocatorImpl;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * Created by it on 2018-04-10.
 */


public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private static final String TAG = "MyAdapter";


    List<ProductVO> items;
    int itemLayout;

    String zuso = "http://211.249.61.120:8000/MusicFactory2/uploadFile/";
    String pic;
    Bitmap bitmap;

    public MyAdapter(List<ProductVO> items, int itemLayout) {
        this.items = items;
        this.itemLayout = itemLayout;
    }

    //row.xml 객체 생성
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(itemLayout, parent, false);
        //parent -> mainActivity.

        Log.i("aa", parent.toString());
        Log.i("aa", parent.getContext().toString());

        return new ViewHolder(view);

    }

    //view 에 data 를 set 하는 역할.
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        ProductVO item = items.get(position);

        holder.tv_title.setText(item.getPname());
        holder.tv_genre.setText(item.getPjanre());
        holder.tv_artist.setText(item.getPauthor());
        holder.tv_price.setText(item.getPprice()+" 원");

        pic = item.getPpicture();

        Thread thread = new Thread(){
            @Override
            public void run() {

                try {
                    Log.i(TAG, zuso+pic+"");
                    URL url = new URL(zuso+pic);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setDoInput(true);
                    conn.connect();

                    InputStream is = conn.getInputStream();
                    bitmap = BitmapFactory.decodeStream(is);

                }catch (Exception e){
                    e.printStackTrace();
                }

            }
        }; // end of Thread

        thread.start();

        try {
            thread.join();
            holder.img.setImageBitmap(bitmap);


        }catch (InterruptedException e){

        }




        //holder.img.setImageResource();
        //holder.itemView.setTag(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView img;
        TextView tv_title, tv_artist, tv_price, tv_genre;

        public ViewHolder(View itemView) {
            super(itemView);

            img = itemView.findViewById(R.id.iv);

            tv_title = itemView.findViewById(R.id.tv_title);
            tv_genre = itemView.findViewById(R.id.tv_genre);
            tv_artist = itemView.findViewById(R.id.tv_artist);
            tv_price = itemView.findViewById(R.id.tv_price);


        }
    }

}

