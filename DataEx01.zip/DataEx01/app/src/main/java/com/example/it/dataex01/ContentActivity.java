package com.example.it.dataex01;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;


public class ContentActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    List items;

    ArrayList<ProductVO> data;


    private static final String TAG = "ContentActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        Intent intent = getIntent();
        data = (ArrayList<ProductVO>) intent.getSerializableExtra("data");

        final Handler handler = new Handler()
        {
            public void handleMessage(Message msg)
            {   Log.i(TAG, "핸들러에용");

                attachView();

            }
        };

        new Thread(){
            public void run() {
                Message message = handler.obtainMessage();
                handler.sendMessage(message);
            }
        }.start();


    }//end of create

    public void attachView(){
        //(1) 리사이클뷰 객체 생성
        recyclerView = findViewById(R.id.recyclerView);

        items = new ArrayList();

        for(int i = 0; i < data.size(); i++) {
            ProductVO product = new ProductVO();
            product.setPname(data.get(i).getPname());
            product.setPjanre(data.get(i).getPjanre());
            product.setPauthor(data.get(i).getPauthor());
            product.setPprice(data.get(i).getPprice());
            product.setPpicture(data.get(i).getPpicture());

            items.add(product);
        }


        //(3) 어댑터 연결 (LayoutManager 설정)
        recyclerView.setAdapter(new MyAdapter(items, R.layout.view));
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

    }//end of attachView

}

