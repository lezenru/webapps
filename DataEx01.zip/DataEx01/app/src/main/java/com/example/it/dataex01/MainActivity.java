package com.example.it.dataex01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    Button btn_1;
    Vector<ProductVO> data;

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Thread(new Runnable() {
            @Override
            public void run() {
                getData();
            }
        }).start();


        btn_1 = findViewById(R.id.btn_1);
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent = new Intent(getApplication(), ContentActivity.class);

                Bundle bundle = new Bundle();

                bundle.putSerializable("data", data);
                intent.putExtras(bundle);

                startActivity(intent);
            }
        });



    }//end of create

    public void getData(){
        try {

            BufferedReader in;

            URL url = new URL("http://222.234.36.90:8001/MFDBServer/getData");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            int responseCode = con.getResponseCode();
            Log.i(TAG,responseCode+"");

            if(responseCode == 200){
                //바이트 단위 스트림이므로 인풋스트림리더-> 버퍼드리더
                //인풋스트림에 utf8 달려있음
                in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            }else{
                in = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }

            String inputData;
            StringBuffer res = new StringBuffer();

            while ((inputData = in.readLine()) != null){

                res.append(inputData);

            }

            in.close();
            Log.i(TAG,res.toString());

            Gson gson = new Gson();

            data = gson.fromJson(res.toString(), new TypeToken<Vector<ProductVO>>(){}.getType());

            Log.i(TAG, "찍혔냐 : "+data.get(0).getMid().toString());

        }catch (Exception e){
            e.printStackTrace();
        }


    }

}
